<html>
<head><title>Dailymotion API upload - royaltalkies.com</title></head>
<?php
setlocale(LC_ALL, 'en_US.UTF8');
		$con = mysql_connect("royal.db.11612931.hostedresource.com", "royal", "Royal@123");
		$db  = mysql_select_db("royal");	

if($_POST){

	$author = $_POST['author'];
	$page 	= $_POST['page'];
	$limit 	= 100;
	$subcategory = $_POST['subcategory'];
	$searchterm	= $_POST['searchterm'];

if($searchterm != ''){	
	$api = "https://api.dailymotion.com/user/$author/videos?fields=allow_embed,embed_url,title,thumbnail_url,thumbnail_small_url,thumbnail_medium_url,thumbnail_large_url,tags,description,allow_comments,explicit,published,owner.videos_total&limit=$limit&page=$page&search=$searchterm";
}else{
	$api = "https://api.dailymotion.com/user/$author/videos?fields=allow_embed,embed_url,title,thumbnail_url,thumbnail_small_url,thumbnail_medium_url,thumbnail_large_url,explicit,tags,description,allow_comments,published,owner.videos_total&limit=$limit&page=$page";
}	
	
	$url = file_get_contents($api);
	$get = json_decode($url);
	
	$inserted = array();
	
	if($get->has_more == true){
	
	?>
	
	<script type="text/javascript">
	function timedRefresh(timeoutPeriod) {
		document.getElementById("form1").submit();
		setTimeout("location.reload(true);",timeoutPeriod);
	}
	</script>


	<?php
	foreach($get->list as $videos){
		if(($videos->allow_embed == 1) && ($videos->published == 1) && ($videos->explicit == false)){
			//print_r($videos);
			$url = $videos->embed_url;
			$tokens = explode('/', $url);

			$embedcode	=  	$tokens[sizeof($tokens)-1];
			$title 		=	$videos->title;
			$thumbnail	= 	$videos->thumbnail_medium_url;
			
			$totaltags = count($videos->tags);
			$i = 1;
			$tags = '';
			foreach($videos->tags as $tag){
				if($i < $totaltags){
					$tags .= $tag.","; 
				}else{
					$tags .= $tag; 
				}
				$i++;
			}
			$tags = $tags;
			$description = $videos->description;
			$uri = toAscii($videos->title, "'");

			$sql 	= "select id from rt_videos order by id desc limit 1";
			$query 	= mysql_query($sql);
			$row	= mysql_fetch_assoc($query);

			$last_id = $row['id'];
			$next_id = $last_id + 1;
			$uriwithid = $uri."-".$next_id;
			
			$insertsql  = "insert into rt_videos (`title`, `embedcode`, `views`, `date`, `desc`, `sub_category`, `uri`, `thumbnail`, `uriwithid`, `tags`) values ";
			$insertsql .= "('$title', '$embedcode', '1', now(), '$description', '$subcategory', '$uri', '$thumbnail', '$uriwithid', '$tags')";
			
			$insertit   = mysql_query($insertsql);
			
			if($insertit){
				$inserted[] = "done";
			}
		}
	}
		echo "HAS MORE VIDEOS<br>";
	}else{
		echo "DOESN'T HAVE ANY VIDEOS<br>";
		exit;
	}
	
	print "<br>From Page $page -> Inserted ".count($inserted)." records";
	
}	

?>

<body onload="JavaScript:timedRefresh(20000);">

<h2>DailyMotion</h2>
<form action="" method="post" name="form1" id="form1">
<?php if($_POST){?>
	<pre>
		Author: <input type="text" name="author" value="<?php echo $author; ?>"><br>
		Page: <input type="text" name="page" value="<?php echo $page + 1; ?>" /> <br>
		Subcategory:<input type="text" name="subcategory" value="<?php echo $subcategory; ?>" /><br>
		Searchterm:<input type="text" name="searchterm" value="<?php echo $searchterm; ?>" /><br>
		<input type="submit" value="submit" />
	</pre>
<?php } else { ?>
	<pre>
		Author: <input type="text" name="author"><br>
		Page: <input type="text" name="page" /> <br>
		Subcategory:<input type="text" name="subcategory" value="" /><br>
		Searchterm:<input type="text" name="searchterm" value="" /><br>
		<input type="submit"  value="submit" />
	</pre>
<?php } ?>
</form>
</body>
</html>

<?php

function toAscii($str, $replace=array(), $delimiter='-') {
		if( !empty($replace) ) {
			$str = str_replace((array)$replace, ' ', $str);
		}

		$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $str);
		$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
		$clean = strtolower(trim($clean, '-'));
		$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);

		return $clean;
}

?>